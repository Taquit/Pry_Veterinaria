import React from "react"

function BlogPage(){
    return(
        <h1>BlogPage</h1>
    )
}

export default BlogPage